# WorkShop backend
Backend application for Workshop.

A REST service on python Flask framework.

# Local development

## Requirements

- [Python 3.8](https://www.python.org/downloads/) or higher
- [Docker](https://docs.docker.com/engine/install/) and [Docker Compose](https://docs.docker.com/compose/install/)

Integration key is '3ddf5f8d-3753-43bc-88b8-d3ad632092b6'
Secret key is '5006423f-513e-4be1-bc19-21e660c91eb8'
URL structure is 'https://account-d.docusign.com/oauth/auth?response_type=code&scope=signature&client_id=3ddf5f8d-3753-43bc-88b8-d3ad632092b6&redirect_uri=http://127.0.0.1:5000/documents/code'

## Run on local machine
Create a virtualenv

```shell script
virtualenv venv
```

Activate virtualenv

```shell script
source venv/bin/activate
```
Start docker-compose services

```shell script
sudo docker-compose up -d
```

For Database initialization

```
flask db init
```

Install  dependencies


```shell script
pip install -r requirements.txt
```

Copy the `.env.example` file to `.env` and change configuration to appropriate values

```shell script
cp .env.example .env
```

Run the migrations

```shell script
flask db upgrade
```

Start the application locally

```shell script
flask run
```

## Running tests

```shell
python -m unittest discover tests
```

```shell
python -m coverage run -m unittest discover
```

```shell
python -m coverage html
```

For creating a new migration

```shell script
flask db migrate -m "migration message"
```


## Environment variables
| Variable                       | Description                                                   |
| -------------                  |:-------------:                                                |
| Some var                       | description .                                                 |

