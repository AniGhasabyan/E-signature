import { useState } from "react";
import { useAuth } from "../hooks/useAuth";

export const HomePage = () => {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [description, setDescription] = useState('');

  const { logout } = useAuth();

  const handleLogin = async (e) => {
      e.preventDefault();
      const response = await fetch('http://127.0.0.1:5000/documents/template', {
          method: 'POST',
          headers: {
              'Content-Type': 'application/json',
          },
          body: JSON.stringify({
              first_name: firstName,
              last_name: lastName,
              email: email,
              description: description,
              callback_url: 'http://localhost/'
          }),
      })
      const data = await response.json();
      window.open(data.redirect_url, '_blank');

  };

return (
    <div>
    <form action="">
      <input 
          type="text" 
          value={firstName}
          onChange={(e) => { setFirstName(e.target.value) }}
          placeholder="First name" 
          required/><br />

      <input 
          type="text" 
          value={lastName}
          onChange={(e) => { setLastName(e.target.value) }}
          placeholder="Last name" 
          required/><br />

      <input 
          type="email"
          value={email}
          onChange={(e) => { setEmail(e.target.value) }}
          autoComplete="email" 
          placeholder="Email address" 
          required/><br />

      <textarea cols="30" rows="8" 
          value={description}
          onChange={(e) => { setDescription(e.target.value) }}
          placeholder="Description"></textarea><br /><br />

      <button onClick={handleLogin}>Send</button>    
    </form>    

    <button type="submit"></button>

        <div>
          <button
            onClick={logout}
            className="flex w-full justify-center rounded-md bg-indigo-600 px-3 py-1.5 text-sm font-semibold leading-6 text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
          >
            Logout
          </button>
        </div>

    </div>
)
}